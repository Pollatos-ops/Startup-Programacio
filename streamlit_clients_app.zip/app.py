import streamlit as st
import pandas as pd
import plotly.express as px

st.title("📊 Visualització de clients per franja horària")

@st.cache_data
def carregar_dades():
    df = pd.read_csv("dades_clients.csv")
    df["hora_dt"] = pd.to_datetime(df["hora"], unit="h").dt.strftime("%H:%M")
    return df

df = carregar_dades()

if st.checkbox("🔍 Mostrar taula de dades"):
    st.dataframe(df)

hores = sorted(df["hora_dt"].unique())
franja = st.selectbox("Selecciona una franja horària:", hores)
df_franja = df[df["hora_dt"] == franja]

st.subheader(f"Clients per caixa a les {franja}")
fig1 = px.bar(df_franja, x="caixa", y="clients", color="caixa", title="Clients per caixa", text="clients")
st.plotly_chart(fig1)

st.subheader(f"Temps mig per client a les {franja}")
fig2 = px.bar(df_franja, x="caixa", y="temps_mig_client", color="caixa", title="Temps mig per client", text="temps_mig_client")
st.plotly_chart(fig2)

st.subheader("Evolució total de clients per hora")
df_agg = df.groupby("hora_dt")["clients"].sum().reset_index()
fig3 = px.line(df_agg, x="hora_dt", y="clients", markers=True, title="Clients totals per hora")
st.plotly_chart(fig3)

st.download_button("💾 Descarrega CSV", data=df.to_csv(index=False), file_name="dades_clients.csv", mime="text/csv")

st.markdown("---")
st.markdown("Made with ❤️ amb Streamlit")
